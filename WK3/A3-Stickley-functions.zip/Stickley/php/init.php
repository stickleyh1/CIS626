<?php
    // start error reporting and session
    error_reporting(E_ALL);
    session_start();
?>